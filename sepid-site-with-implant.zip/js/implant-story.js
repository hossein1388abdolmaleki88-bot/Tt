/* Sepid SVG anatomy: genuine paths, gradients, porous bone, enamel and metal.
   All motion operates on independent SVG groups. No photos, videos, or canvas. */
const section=document.querySelector('#implant-story');
if(section){
 const $=s=>section.querySelector(s), $$=s=>[...section.querySelectorAll(s)];
 const visual=$('.implant-visual'), reduced=matchMedia('(prefers-reduced-motion: reduce)'), short=matchMedia('(max-height:520px)');
 const copies=$$('.implant-copy'),dots=$$('.implant-rail button'),counter=$('[data-current]'),finale=$('.implant-finale-label');
 const digits=['۱','۲','۳','۴','۵'],DURATION=1180,QUIET=280;
 const states=[
  {c:190,a:330,s:470,j:0,jy:76,r:0,co:1,ao:1},
  {c:80,a:390,s:610,j:0,jy:76,r:0,co:1,ao:1},
  {c:-270,a:-250,s:275,j:1,jy:0,r:1,co:0,ao:0},
  {c:-270,a:-250,s:560,j:1,jy:0,r:1,co:0,ao:0},
  {c:335,a:460,s:560,j:1,jy:0,r:1,co:1,ao:1}
 ];
 const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
 const ease=n=>{n=clamp(n);return n<.5?4*n*n*n:1-Math.pow(-2*n+2,3)/2};
 const mix=(a,b,t)=>a+(b-a)*t;
 let enabled=false,broken=false,pinned=false,busy=false,index=0,from=0,to=0,queue=null,started=0,raf=0;
 let wheelLast=0,wheelBurst=false,lastY=scrollY,touchStart=null,scene=null;
 const nodes={};
 function paint(progress=1){
  if(!scene)return;
  const k=busy?ease(progress):1;
  const st={};for(const key of Object.keys(states[0]))st[key]=mix(states[from][key],states[to][key],k);
  // The restorative step is sequenced: connector first, then enamel crown.
  if(busy&&from===3&&to===4){const ap=ease(clamp((progress-.07)/.45)),cp=ease(clamp((progress-.44)/.54));st.a=mix(-250,460,ap);st.ao=ap;st.c=mix(-270,335,cp);st.co=cp;}
  if(busy&&from===4&&to===3){const cp=ease(clamp((progress-.02)/.54)),ap=ease(clamp((progress-.50)/.45));st.c=mix(335,-270,cp);st.co=1-cp;st.a=mix(460,-250,ap);st.ao=1-ap;}
  nodes.crown.setAttribute('transform',`translate(500 ${st.c.toFixed(2)})`);nodes.crown.style.opacity=st.co;
  nodes.abut.setAttribute('transform',`translate(500 ${st.a.toFixed(2)})`);nodes.abut.style.opacity=st.ao;
  const planting=busy&&((from===2&&to===3)||(from===3&&to===2));
  const axial=planting?Math.sin(k*Math.PI*5):0;
  nodes.screw.setAttribute('transform',`translate(500 ${st.s.toFixed(2)}) rotate(${(axial*3).toFixed(2)}) scale(${(1-.09*Math.abs(axial)).toFixed(3)} 1)`);
  nodes.jaw.setAttribute('transform',`translate(0 ${st.jy.toFixed(2)}) scale(1 ${(0.94+.06*st.j).toFixed(3)})`);
  nodes.jaw.style.opacity=st.j;nodes.rim.style.opacity=st.r;
  nodes.shadow.setAttribute('rx',String(mix(145,205,st.j)));
  const shine=planting?Math.sin(Math.PI*k)*.18:0;
  nodes.glint.style.opacity=busy&&((from===3&&to===4)||(from===4&&to===3))?Math.sin(Math.PI*clamp((k-.55)/.45))*.9:0;
  nodes.screw.style.filter=shine?`brightness(${(1+shine).toFixed(2)})`:'';
  copies.forEach((node,i)=>{const alpha=busy?(i===from?1-k:i===to?k:0):(i===index?1:0);node.style.opacity=alpha;node.style.transform=`translate3d(0,${(i===from&&busy?-18*k:24*(1-alpha)).toFixed(1)}px,0)`;node.setAttribute('aria-hidden',alpha>.5?'false':'true');});
  const f=busy?(from===4?1-k:to===4?k:0):index===4?1:0;
  finale.style.opacity=f;finale.style.transform=`translate(-50%,${14*(1-f)}px)`;
 }
 function controls(){dots.forEach((dot,i)=>i===index?dot.setAttribute('aria-current','step'):dot.removeAttribute('aria-current'));counter.textContent=digits[index];visual.classList.toggle('is-idle',index===0&&!busy&&pinned);paint();}
 function frame(now){raf=0;if(!busy)return;const p=clamp((now-started)/DURATION);paint(p);if(p>=1){busy=false;index=to;from=to;controls();if(queue!==null&&queue!==index){let dest=queue;queue=null;change(Math.sign(dest-index));queue=dest;}else queue=null;}else raf=requestAnimationFrame(frame);}
 function change(dir){if(!pinned||busy||!scene)return;const next=index+dir;if(next<0||next>4){leave(dir);return;}from=index;to=next;busy=true;started=performance.now();visual.classList.remove('is-idle');raf=requestAnimationFrame(frame);}
 function jump(dest){if(!pinned||dest===index)return;queue=dest;if(!busy)change(Math.sign(dest-index));}
 function bounds(){const r=section.getBoundingClientRect();return{top:r.top+scrollY,bottom:r.bottom+scrollY};}
 function scrollNow(y){const h=document.documentElement,p=h.style.scrollBehavior;h.style.scrollBehavior='auto';scrollTo(0,Math.max(0,Math.round(y)));h.style.scrollBehavior=p;}
 function enter(dir){if(pinned||!enabled||!scene)return;pinned=true;busy=false;queue=null;index=dir>0?0:4;from=to=index;scrollNow(bounds().top);controls();}
 function leave(dir){pinned=false;visual.classList.remove('is-idle');const b=bounds();scrollNow(dir>0?b.bottom+2:b.top-innerHeight*.83);}
 function editable(el){return el instanceof Element&&!!el.closest('input,textarea,select,[contenteditable="true"],dialog[open]');}
 function wheel(e){if(!enabled||!scene||editable(e.target)||e.ctrlKey)return;const d=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?innerHeight:1);if(Math.abs(d)<2)return;const dir=Math.sign(d),y=scrollY,b=bounds();if(!pinned){const inside=y>=b.top&&y<b.bottom;const cross=inside||(dir>0?y<b.top&&y+Math.max(50,d)>=b.top-15:y>=b.bottom&&y+Math.min(-50,d)<=b.bottom+15);if(!cross)return;e.preventDefault();enter(dir);wheelBurst=true;wheelLast=performance.now();return;}e.preventDefault();const now=performance.now(),fresh=!wheelBurst||now-wheelLast>QUIET;wheelLast=now;wheelBurst=true;if(fresh&&!busy)change(dir);}
 function key(e){if(!enabled||editable(e.target)||e.altKey||e.ctrlKey||e.metaKey||e.repeat)return;let dir=0;if(['ArrowDown','PageDown'].includes(e.key))dir=1;if(['ArrowUp','PageUp'].includes(e.key))dir=-1;if(e.code==='Space')dir=e.shiftKey?-1:1;if(!dir)return;if(!pinned){const y=scrollY,b=bounds();if(dir>0&&y<=b.top&&b.top-y<innerHeight*.85||dir<0&&y>=b.bottom&&y-b.bottom<innerHeight*.85){e.preventDefault();enter(dir);}}else{e.preventDefault();change(dir);}}
 function touchMove(e){if(!enabled||!touchStart||editable(e.target))return;const d=touchStart.y-e.touches[0].clientY,y=scrollY,b=bounds();const near=d>0?y<b.top&&b.top-y<innerHeight*.35:y>=b.bottom&&y-b.bottom<innerHeight*.35;if(pinned||near||y>=b.top&&y<b.bottom)e.preventDefault();}
 function touchEnd(e){if(!enabled||!touchStart||!e.changedTouches.length)return;const d=touchStart.y-e.changedTouches[0].clientY;touchStart=null;if(Math.abs(d)<36)return;const dir=Math.sign(d);if(pinned){if(!busy)change(dir);return;}const y=scrollY,b=bounds();if(dir>0&&y<=b.top&&b.top-y<innerHeight*.4||dir<0&&y>=b.bottom&&y-b.bottom<innerHeight*.4)enter(dir);}
 function sync(){enabled=!reduced.matches&&!short.matches&&!broken;section.classList.toggle('is-enhanced',enabled);if(!enabled){pinned=false;busy=false;cancelAnimationFrame(raf);}else controls();}
 dots.forEach(dot=>dot.addEventListener('click',()=>jump(Number(dot.dataset.step))));
 document.addEventListener('wheel',wheel,{passive:false,capture:true});document.addEventListener('keydown',key,true);
 document.addEventListener('touchstart',e=>{if(e.touches.length===1)touchStart={y:e.touches[0].clientY};},{passive:true,capture:true});
 document.addEventListener('touchmove',touchMove,{passive:false,capture:true});document.addEventListener('touchend',touchEnd,{passive:true,capture:true});
 section.addEventListener('pointermove',e=>{if(e.pointerType==='touch'||!visual.classList.contains('is-idle'))return;const r=section.getBoundingClientRect();visual.style.setProperty('--pointer-x',`${((e.clientX-r.left-r.width/2)*.012).toFixed(1)}px`);visual.style.setProperty('--pointer-y',`${((e.clientY-r.top-r.height/2)*.008).toFixed(1)}px`);},{passive:true});
 section.addEventListener('pointerleave',()=>{visual.style.setProperty('--pointer-x','0px');visual.style.setProperty('--pointer-y','0px');});
 reduced.addEventListener('change',sync);short.addEventListener('change',sync);
 window.addEventListener('scroll',()=>{const y=scrollY,b=bounds();if(enabled&&!pinned&&!location.hash&&y>b.top+24&&y<b.bottom-24)enter(y>=lastY?1:-1);lastY=y;},{passive:true});
 sync();
 // Fetch editable vector source. Until it arrives the first SVG still is visible.
 fetch('assets/implant/implant-scene.svg').then(r=>{if(!r.ok)throw Error(r.status);return r.text();}).then(text=>{
  const doc=new DOMParser().parseFromString(text,'image/svg+xml');if(doc.querySelector('parsererror'))throw Error('SVG parse error');
  scene=document.importNode(doc.documentElement,true);scene.classList.add('implant-svg');visual.replaceChildren(scene);
  nodes.crown=scene.querySelector('#implant-crown');nodes.abut=scene.querySelector('#implant-abutment');nodes.screw=scene.querySelector('#implant-screw');nodes.jaw=scene.querySelector('#jaw-scene');nodes.rim=scene.querySelector('#socket-rim');nodes.glint=scene.querySelector('#tooth-glint');nodes.shadow=scene.querySelector('#ground-shadow');
  if(!Object.values(nodes).every(Boolean))throw Error('Missing SVG layer');controls();
 }).catch(error=>{broken=true;sync();console.error('Implant SVG unavailable:',error);});
}
