# نسخهٔ تمام‌برداری ایمپلنت سپید

این نسخه به درخواست جدید جای ویدیو/عکس را گرفته است. صحنهٔ اصلی `assets/implant/implant-scene.svg` فقط از path، gradient، clipPath، filter و شکل‌های SVG ساخته شده است؛ هیچ تصویر raster، video، canvas یا CSS background-image با عکس در بخش ایمپلنت استفاده نمی‌شود.

اجزا گروه‌های مستقل `#implant-crown`، `#implant-abutment`، `#implant-screw`، `#jaw-scene` و `#socket-rim` هستند. رزوه‌های پیج، منفذهای استخوان، دندان‌های مجاور، مینای چندلایه، رابط طلایی، سایهٔ زمین و لثهٔ آبی یخی با مسیرهای برداری ترسیم شده‌اند. JS فقط transform و opacity گروه‌ها را حرکت می‌دهد: از حالت متصل، بازشدن، ورود فک، حرکت مارپیچی پیچ و در پایان نشستن رابط و سپس تاج.

## اجرا روی موبایل یا رایانه

در پوشهٔ پروژه `python serve.py` را اجرا کنید و در **مرورگر همان دستگاه** `http://127.0.0.1:3000/index.html` را باز کنید. روی Pydroid ترمینال باید باز بماند؛ خروجی سایت در مرورگر است نه ترمینال. اگر پورت اشغال است `python serve.py 3001` و آدرس `http://127.0.0.1:3001/index.html` را باز کنید.

## افزودن بخش به سایت موجود

1. تمام فایل‌های SVG در `assets/implant/`، فایل `assets/implant-story.css` و `js/implant-story.js` را در همان مسیرها کپی کنید.
2. محتوای `implant-story.html` را درون `<main>` بلافاصله بعد از `#home` و قبل از `#services` قرار دهید.
3. در `<head>` پس از CSSهای فعلی اضافه کنید: `<link rel="stylesheet" href="assets/implant-story.css">` و `<link rel="preload" as="image" href="assets/implant/implant-step-01.svg">`.
4. پیش از `</body>` اضافه کنید: `<script type="module" src="js/implant-story.js"></script>`.

`tools/build_implant_svg.py` فایل SVG اصلی و پنج فریم ثابتِ تمام‌برداری را بازتولید می‌کند؛ فقط به Python استاندارد نیاز دارد. در اجرای خود سایت هیچ build یا کتابخانهٔ خارجی لازم نیست. هنگام `prefers-reduced-motion`، صفحهٔ کم‌ارتفاع، قطع JS یا خطای بارگذاری، پنج فصل SVG ثابت پشت سر هم نمایش داده می‌شوند.
